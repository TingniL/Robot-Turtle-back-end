package com.company;


public class Main {
    public static void main(String[] args) {
        Menu men = new Menu();
        Bg bg = new Bg();
        //Plateau plat = new Plateau();

    }
}
